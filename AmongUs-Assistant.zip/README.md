# Among Us Assistant

Companion Android app for the official Among Us mobile game.

## V0.1
- Android app shell
- User-authorized floating overlay
- Draggable bubble
- Expandable assistant panel

The app does not read hidden game state or interact with the game process. Future screen analysis will use Android's visible-screen capture permission, requested explicitly from the user.
