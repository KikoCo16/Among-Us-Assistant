# Among Us Assistant — V1

Application Android Kotlin native, conçue comme compagnon local pour Among Us Mobile.

## Fonctionnalités effectivement présentes
- Autorisation Android MediaProjection demandée explicitement.
- Capture d'écran locale et OCR ML Kit sur l'appareil.
- Bulle flottante déplaçable et menu avec réduire, masquer et arrêt complet.
- Notification persistante avec action ARRÊTER.
- Stockage SQLite local des joueurs et observations.
- Ajout manuel de faits, déclarations, déductions et contradictions.
- Classification heuristique CLEAR / NEUTRAL / SUSPECT avec explication prudente.
- Suppression de toutes les données locales.

## Limites honnêtes de cette V1
L'OCR conserve des extraits de texte visibles, mais ne comprend pas encore le contexte du jeu. Il ne détecte pas de façon fiable les avatars/couleurs/salles, ne suit pas automatiquement les positions, n'attribue pas les messages à un locuteur, ne lit pas les votes et ne détecte pas les éliminations. Les extraits OCR ont une confiance indicative fixe de 55 % et doivent être vérifiés. La V1 ne prétend donc pas fournir une analyse automatique complète de partie.

La capture est initiée par l'utilisateur, les images ne sont ni archivées ni transmises. Seuls des extraits de texte OCR sont enregistrés localement.

## Compiler
Prérequis : JDK 17, Android SDK Platform 35 et Gradle 8.9+.
Depuis ce dossier :
```bash
gradle assembleDebug
```
APK : `app/build/outputs/apk/debug/app-debug.apk`

Le workflow GitHub fourni séparément extrait `AmongUs-Assistant.zip` puis compile le projet.
