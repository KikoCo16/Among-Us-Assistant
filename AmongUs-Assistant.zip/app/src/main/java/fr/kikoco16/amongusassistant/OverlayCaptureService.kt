package fr.kikoco16.amongusassistant

import android.app.*
import android.content.pm.ServiceInfo
import android.content.*
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class OverlayCaptureService : Service() {
    companion object {
        const val ACTION_START="fr.kikoco16.START"
        const val ACTION_STOP="fr.kikoco16.STOP"
        const val EXTRA_RESULT_CODE="result_code"
        const val EXTRA_DATA="projection_data"
        private const val CHANNEL="amongus_capture"
        private const val NOTIFICATION_ID=41
    }
    private var projection:MediaProjection?=null
    private var virtualDisplay:VirtualDisplay?=null
    private var reader:ImageReader?=null
    private var window:WindowManager?=null
    private var bubble:View?=null
    private var panel:View?=null
    private var params:WindowManager.LayoutParams?=null
    private var lastOcr=0L
    @Volatile private var lastRecognizedText=""
    private val processing=AtomicBoolean(false)
    private val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val handler=Handler(Looper.getMainLooper())

    override fun onBind(intent:Intent?)=null
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action==ACTION_STOP){ stopSelf(); return START_NOT_STICKY }
        if(intent?.action==ACTION_START) {
            createChannel()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification())
            }
            try {
                val code=intent.getIntExtra(EXTRA_RESULT_CODE,Activity.RESULT_CANCELED)
                val data=intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: run { stopSelf(); return START_NOT_STICKY }
                val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection=mgr.getMediaProjection(code,data)
                startCapture()
                showBubble()
            } catch (_:Exception) { stopSelf() }
        }
        return START_NOT_STICKY
    }
    private fun createChannel() {
        if(Build.VERSION.SDK_INT>=26) {
            val ch=NotificationChannel(CHANNEL,"Capture Among Us",NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
    private fun notification():Notification {
        val stop=PendingIntent.getService(this,9,Intent(this,OverlayCaptureService::class.java).setAction(ACTION_STOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,CHANNEL)
            .setContentTitle("Among Us Assistant actif").setContentText("Capture locale • appuie sur ARRÊTER pour terminer")
            .setSmallIcon(android.R.drawable.ic_menu_view).addAction(Notification.Action.Builder(null,"ARRÊTER",stop).build()).build()
        else Notification.Builder(this).setContentTitle("Among Us Assistant actif").setSmallIcon(android.R.drawable.ic_menu_view).build()
    }
    private fun startCapture() {
        val dm=resources.displayMetrics
        val w=dm.widthPixels; val h=dm.heightPixels; val density=dm.densityDpi
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
        reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2)
        reader?.setOnImageAvailableListener({ r ->
            val now=System.currentTimeMillis()
            if(now-lastOcr<1800 || !processing.compareAndSet(false,true)) { r.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image=r.acquireLatestImage() ?: run { processing.set(false); return@setOnImageAvailableListener }
            lastOcr=now
            val input=try { InputImage.fromMediaImage(image,0) } catch (_:Exception) { image.close(); processing.set(false); return@setOnImageAvailableListener }
            recognizer.process(input).addOnSuccessListener { result ->
                val text=result.text.trim()
                if(text.isNotBlank() && text != lastRecognizedText) {
                    lastRecognizedText=text
                    Store(this).addObservation("OCR","", "", "Texte visible : "+text.take(700), "OCR écran", 55)
                }
            }.addOnCompleteListener { image.close(); processing.set(false) }
        },Handler(Looper.getMainLooper()))
        virtualDisplay=projection?.createVirtualDisplay("AmongUsAssistant",w,h,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,null)
    }
    private fun showBubble() {
        window=getSystemService(WINDOW_SERVICE) as WindowManager
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val b=TextView(this).apply {
            text="AU"; textSize=16f; setTextColor(Color.WHITE); gravity=Gravity.CENTER
            setBackgroundColor(Color.rgb(28,105,220)); elevation=10f
            setOnTouchListener(DragTouch())
            setOnClickListener { togglePanel() }
        }
        val p=WindowManager.LayoutParams(58,58,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.START; x=30; y=180
        }
        params=p; bubble=b
        try { window?.addView(b,p) } catch (_:Exception) { stopSelf() }
    }
    private inner class DragTouch:View.OnTouchListener {
        private var sx=0f; private var sy=0f; private var ox=0; private var oy=0; private var dragged=false
        override fun onTouch(v:View,e:android.view.MotionEvent):Boolean {
            val p=params ?: return false
            when(e.action) {
                MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=p.x;oy=p.y;dragged=false;return true}
                MotionEvent.ACTION_MOVE->{val dx=(e.rawX-sx).toInt();val dy=(e.rawY-sy).toInt();if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8)dragged=true;p.x=ox+dx;p.y=oy+dy;try{window?.updateViewLayout(v,p)}catch(_:Exception){};return true}
                MotionEvent.ACTION_UP->{if(!dragged) v.performClick();return true}
            }
            return true
        }
    }
    private fun togglePanel() {
        if(panel!=null){ removePanel(); return }
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,14,18,14); setBackgroundColor(Color.rgb(12,25,49)) }
        fun action(text:String,run:()->Unit) {
            box.addView(Button(this).apply { this.text=text; setOnClickListener { run() } })
        }
        box.addView(TextView(this).apply { text="ANALYSE EN COURS • OCR local";setTextColor(Color.WHITE);textSize=16f })
        action("Ouvrir l'application"){ val i=packageManager.getLaunchIntentForPackage(packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); if(i!=null)startActivity(i) }
        action("Réduire"){removePanel()}
        action("Masquer la bulle"){removePanel();try{window?.removeView(bubble);bubble=null}catch(_:Exception){}}
        action("ARRÊTER / ✕"){stopSelf()}
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val pp=WindowManager.LayoutParams((resources.displayMetrics.widthPixels*0.78).toInt(),WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL;x=0;y=260
        }
        panel=box
        try{window?.addView(box,pp)}catch(_:Exception){panel=null}
    }
    private fun removePanel(){try{panel?.let{window?.removeView(it)}}catch(_:Exception){};panel=null}
    override fun onDestroy() {
        removePanel()
        try{bubble?.let{window?.removeView(it)}}catch(_:Exception){}
        bubble=null
        virtualDisplay?.release();virtualDisplay=null
        reader?.close();reader=null
        projection?.stop();projection=null
        recognizer.close()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
