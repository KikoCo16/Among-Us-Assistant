package fr.kikoco16.amongusassistant

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var status: TextView
    private val projectionRequest = 701
    private val bg = Color.rgb(7, 15, 34)
    private val panel = Color.rgb(15, 29, 57)
    private val blue = Color.rgb(40, 130, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        renderHome()
    }
    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22, 26, 22, 24); setBackgroundColor(bg)
        }
        val head = TextView(this).apply { text = title; textSize = 25f; setTextColor(Color.WHITE); setPadding(0,0,0,18) }
        root.addView(head)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        root.tag = content
        return root
    }
    private fun content(root: LinearLayout) = root.tag as LinearLayout
    private fun label(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply { this.text=text; textSize=14f; setTextColor(Color.LTGRAY); setPadding(0,10,0,10) })
    }
    private fun button(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(Button(this).apply { this.text=text; setTextColor(Color.WHITE); setBackgroundColor(panel); setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin=8 })
    }
    private fun field(hint: String) = EditText(this).apply {
        this.hint=hint; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); textSize=16f
        setPadding(14,10,14,10); setBackgroundColor(panel)
    }
    private fun renderHome() {
        val root=base("Among Us Assistant")
        val c=content(root)
        label(c,"Compagnon local • Android 8+ • données stockées sur le téléphone")
        status=TextView(this).apply { setTextColor(Color.rgb(100,220,160)); textSize=16f; text="Service flottant : état à vérifier"; setPadding(0,10,0,18) }
        c.addView(status)
        button(c,"DÉMARRER la capture et la bulle") { startCaptureFlow() }
        button(c,"ARRÊTER complètement le service") { stopService(Intent(this,OverlayCaptureService::class.java)); status.text="Service arrêté" }
        button(c,"Autoriser l'affichage par-dessus les autres applications") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button(c,"Joueurs") { renderPlayers() }
        button(c,"Chronologie / observations") { renderTimeline() }
        button(c,"Ajouter une observation") { addObservationDialog() }
        button(c,"Réunions") { renderMeetings() }
        button(c,"Paramètres et données") { renderSettings() }
        label(c,"Limite V1 : la reconnaissance OCR lit du texte visible à l'écran. Elle ne sait pas encore identifier de façon fiable les couleurs, les salles, les avatars, les morts ou attribuer automatiquement chaque message à son auteur.")
    }
    private fun startCaptureFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this,"Autorise d'abord l'affichage par-dessus les autres applications.",Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val manager=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(),projectionRequest)
    }
    @Deprecated("Activity result compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==projectionRequest && resultCode==RESULT_OK && data!=null) {
            val intent=Intent(this,OverlayCaptureService::class.java).apply {
                action=OverlayCaptureService.ACTION_START
                putExtra(OverlayCaptureService.EXTRA_RESULT_CODE,resultCode)
                putExtra(OverlayCaptureService.EXTRA_DATA,data)
            }
            startForegroundService(intent)
            Toast.makeText(this,"Capture autorisée. La bulle est lancée.",Toast.LENGTH_SHORT).show()
        }
    }
    private fun renderPlayers() {
        val root=base("Joueurs"); val c=content(root)
        val name=field("Nom unique du joueur"); c.addView(name)
        val color=field("Couleur (ex. rouge, bleu)"); c.addView(color)
        button(c,"Ajouter le joueur") {
            if(store.addPlayer(name.text.toString(),color.text.toString().ifBlank{"Non définie"})) renderPlayers()
            else Toast.makeText(this,"Nom vide ou déjà utilisé.",Toast.LENGTH_SHORT).show()
        }
        store.players().forEach { p ->
            label(c,"${p.name} • ${p.color} • ${p.status}\n${p.classification} — ${p.reason}")
        }
        button(c,"Retour") { renderHome() }
    }
    private fun addObservationDialog() {
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,8,24,0) }
        val kind=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("FAIT","DÉCLARATION","DÉDUCTION","CONTRADICTION","RÉUNION")) }
        val subject=field("Joueur concerné (facultatif)")
        val room=field("Salle (facultatif)")
        val detail=field("Description de l'observation")
        val source=field("Source (OCR / utilisateur / discussion)")
        layout.addView(kind); layout.addView(subject); layout.addView(room); layout.addView(detail); layout.addView(source)
        AlertDialogBuilder.show(this,"Nouvelle observation",layout) {
            store.addObservation(kind.selectedItem.toString(),subject.text.toString(),room.text.toString(),detail.text.toString(),source.text.toString().ifBlank{"Utilisateur"},100)
            renderTimeline()
        }
    }
    private fun renderTimeline() {
        val root=base("Chronologie"); val c=content(root)
        store.observations().forEach { o ->
            val date=java.text.SimpleDateFormat("HH:mm:ss",java.util.Locale.FRANCE).format(java.util.Date(o.time))
            val t=TextView(this).apply {
                text="$date • ${o.kind} • ${o.subject}\n${o.detail}\n${o.room} • ${o.source} • confiance ${o.confidence}%"
                textSize=14f; setTextColor(Color.WHITE); setPadding(12,12,12,12); setBackgroundColor(panel)
            }
            c.addView(t)
            button(c,"Supprimer cette observation") { store.deleteObservation(o.id); renderTimeline() }
        }
        button(c,"Ajouter") { addObservationDialog() }
        button(c,"Retour") { renderHome() }
    }
    private fun renderMeetings() {
        val root=base("Réunions"); val c=content(root)
        label(c,"Les messages de réunion détectés par OCR sont conservés comme texte brut dans le journal de capture. L'attribution du locuteur et les votes doivent être confirmés manuellement.")
        button(c,"Ajouter une déclaration / accusation") { addObservationDialog() }
        button(c,"Voir la chronologie") { renderTimeline() }
        button(c,"Retour") { renderHome() }
    }
    private fun renderSettings() {
        val root=base("Paramètres"); val c=content(root)
        label(c,"Capture : locale, arrêtée avec le service. Les images ne sont pas enregistrées ni envoyées. L'OCR est effectué sur l'appareil.")
        button(c,"Supprimer toutes les données locales") {
            android.app.AlertDialog.Builder(this).setTitle("Tout supprimer ?").setMessage("Cette action efface joueurs et observations.")
                .setNegativeButton("Annuler",null).setPositiveButton("Supprimer") { _,_->store.clearAll(); renderSettings() }.show()
        }
        button(c,"Retour") { renderHome() }
    }
}
