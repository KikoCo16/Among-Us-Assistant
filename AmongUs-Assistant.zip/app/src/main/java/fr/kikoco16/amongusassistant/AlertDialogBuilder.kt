package fr.kikoco16.amongusassistant

import android.content.Context
import android.app.AlertDialog
import android.view.View

object AlertDialogBuilder {
    fun show(context: Context, title: String, view: View, onSave: () -> Unit) {
        AlertDialog.Builder(context).setTitle(title).setView(view)
            .setNegativeButton("Annuler",null).setPositiveButton("Enregistrer") { _,_-> onSave() }.show()
    }
}
