package fr.kikoco16.amongusassistant

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues

data class Player(val id: Long, val name: String, val color: String, val status: String, val classification: String, val reason: String)
data class Observation(val id: Long, val time: Long, val kind: String, val subject: String, val room: String, val detail: String, val source: String, val confidence: Int)

class Store(context: Context) : SQLiteOpenHelper(context, "amongus_assistant.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE players(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, color TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'INCONNU')")
        db.execSQL("CREATE TABLE observations(id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, kind TEXT NOT NULL, subject TEXT, room TEXT, detail TEXT NOT NULL, source TEXT NOT NULL, confidence INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE meetings(id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, summary TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addPlayer(nameRaw: String, color: String): Boolean {
        val name = nameRaw.trim()
        if (name.isBlank()) return false
        return try {
            val values = ContentValues().apply { put("name", name); put("color", color); put("status", "INCONNU") }
            writableDatabase.insertOrThrow("players", null, values) > 0
        } catch (_: Exception) { false }
    }
    fun players(): List<Player> {
        val out = mutableListOf<Player>()
        readableDatabase.rawQuery("SELECT id,name,color,status FROM players ORDER BY name", null).use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1)
                val analysis = classify(name)
                out += Player(c.getLong(0), name, c.getString(2), c.getString(3), analysis.first, analysis.second)
            }
        }
        return out
    }
    fun addObservation(kind: String, subject: String, room: String, detail: String, source: String, confidence: Int) {
        val v = ContentValues().apply {
            put("time", System.currentTimeMillis()); put("kind", kind); put("subject", subject)
            put("room", room); put("detail", detail); put("source", source); put("confidence", confidence.coerceIn(0,100))
        }
        writableDatabase.insert("observations", null, v)
    }
    fun observations(): List<Observation> {
        val out = mutableListOf<Observation>()
        readableDatabase.rawQuery("SELECT id,time,kind,subject,room,detail,source,confidence FROM observations ORDER BY time DESC LIMIT 250", null).use { c ->
            while (c.moveToNext()) out += Observation(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3) ?: "",c.getString(4) ?: "",c.getString(5),c.getString(6),c.getInt(7))
        }
        return out
    }
    fun deleteObservation(id: Long) { writableDatabase.delete("observations", "id=?", arrayOf(id.toString())) }
    fun clearAll() { writableDatabase.delete("observations", null, null); writableDatabase.delete("players", null, null); writableDatabase.delete("meetings", null, null) }

    private fun classify(player: String): Pair<String,String> {
        val rows = observations().filter { it.subject.equals(player, true) || it.detail.contains(player, true) }
        val contradictions = rows.count { it.kind == "CONTRADICTION" }
        val direct = rows.count { it.kind == "FAIT" && it.confidence >= 75 }
        return when {
            contradictions >= 2 -> "SUSPECT" to "$contradictions incohérences consignées. Cela ne prouve pas une culpabilité."
            direct >= 2 -> "CLEAR" to "$direct observations directes fiables. Ce n'est pas une preuve absolue."
            else -> "NEUTRAL" to "Informations insuffisantes pour conclure."
        }
    }
}
