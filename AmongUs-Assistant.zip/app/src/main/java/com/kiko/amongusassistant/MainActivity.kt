package com.kiko.amongusassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(12, 18, 32))
        }

        val title = TextView(this).apply {
            text = "Among Us Assistant"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val description = TextView(this).apply {
            text = "V0.1 — Menu flottant\\n\\nAutorise l'affichage par-dessus les autres applications pour utiliser le bouton flottant pendant une partie."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }

        val permissionButton = Button(this).apply {
            text = "Autoriser le menu flottant"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    startOverlay()
                }
            }
        }

        val startButton = Button(this).apply {
            text = "Lancer / afficher le menu"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startOverlay()
                } else {
                    permissionButton.performClick()
                }
            }
        }

        root.addView(title, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(description)
        root.addView(permissionButton)
        root.addView(startButton)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) {
            // The user can now launch the overlay with the button.
        }
    }

    private fun startOverlay() {
        startService(Intent(this, OverlayService::class.java))
        finish()
    }
}
