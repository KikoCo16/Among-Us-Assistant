package com.kiko.amongusassistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private var expanded = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createBubble()
    }

    private fun overlayType(): Int =
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun createBubble() {
        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        bubble = TextView(this).apply {
            text = "AU"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(40, 110, 220))
            setOnTouchListener(DragTouchListener())
            setOnClickListener {
                if (!dragged) togglePanel()
            }
        }
        windowManager.addView(bubble, bubbleParams)
    }

    private var dragged = false

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragged = false
                    startX = bubbleParams.x
                    startY = bubbleParams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 5 || kotlin.math.abs(dy) > 5) dragged = true
                    bubbleParams.x = startX + dx
                    bubbleParams.y = startY + dy
                    windowManager.updateViewLayout(bubble, bubbleParams)
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) togglePanel()
                    return true
                }
            }
            return false
        }
    }

    private fun togglePanel() {
        if (expanded) {
            panel?.let { windowManager.removeView(it) }
            panel = null
            expanded = false
            return
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(Color.rgb(20, 28, 45))
        }

        val heading = TextView(this).apply {
            text = "ASSISTANT"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 12)
        }
        val status = TextView(this).apply {
            text = "Analyse : en attente\n\nAucune donnée de partie détectée pour le moment."
            textSize = 14f
            setTextColor(Color.LTGRAY)
        }
        val close = TextView(this).apply {
            text = "Fermer"
            textSize = 14f
            setTextColor(Color.rgb(120, 180, 255))
            setPadding(0, 16, 0, 0)
            setOnClickListener { togglePanel() }
        }

        content.addView(heading)
        content.addView(status)
        content.addView(close)

        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleParams.x
            y = bubbleParams.y + 65
        }
        panel = content
        windowManager.addView(content, panelParams)
        expanded = true
    }

    override fun onDestroy() {
        bubble?.let { windowManager.removeView(it) }
        panel?.let { windowManager.removeView(it) }
        bubble = null
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
